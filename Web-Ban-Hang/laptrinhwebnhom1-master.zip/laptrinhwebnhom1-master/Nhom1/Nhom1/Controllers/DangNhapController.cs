﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Nhom1.Controllers
{
    public class DangNhapController : Controller
    {
        //
        // GET: /DangNhap/
        public ActionResult Index()
        {
            return View();
        }
	}
}